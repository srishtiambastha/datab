package dataPack;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Del
{

	public static void main(String[] args) throws Exception
	{
		Class.forName("org.h2.Driver");
		Connection con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","");
		PreparedStatement pst=con.prepareStatement("delete customer where id=202");
		
		pst.executeUpdate();
		pst.close();
		con.close();
		
		
		System.out.println("data is deleted");
		
	}

}
